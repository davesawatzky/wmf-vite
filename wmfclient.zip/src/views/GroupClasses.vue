<template>
  <div class="pb-8">
    <h2 class="pb-4">Group Class Information</h2>
    <Class />
  </div>
  <BaseRouteButton type="button" to="/groupcontactinfo" class="btn btn-blue"
    >Previous</BaseRouteButton
  >
  <BaseRouteButton type="button" to="/summary" class="btn btn-blue"
    >Next</BaseRouteButton
  >
</template>

<script setup lang="ts"></script>

<style scoped></style>
