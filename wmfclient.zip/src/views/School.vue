<template>
	<div>
		<h1>School Info</h1>
	</div>
</template>

<script setup lang="ts"></script>

<style lang="scss" scoped></style>
