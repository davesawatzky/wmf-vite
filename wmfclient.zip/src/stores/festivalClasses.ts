import { defineStore } from 'pinia'

// Thinking about using a Store to hold all the festival classes
// Rather than using Apollo Cache.
// Still deciding
export const festivalClasses = defineStore('festivalClasses', {
  state: () => ({}),
})
